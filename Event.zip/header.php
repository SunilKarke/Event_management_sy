<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/db.php';
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Events Manage</title>
  <link rel="stylesheet" href="/Event_M/css/style.css">
</head>
<body>
  <header>
    <div class="container">
      <h1><a href="/Event_M/">Event_Management</a></h1>
      <nav>
        <a href="/Event_M/">Home</a>
        <?php if(!empty($_SESSION['user_id'])): ?>
          <?php if(function_exists('is_admin') && is_admin()): ?>
            <a href="/Event_M/add_event.php">Add Event</a>
            <a href="/Event_M/admin.php">Admin Panel</a>
          <?php endif; ?>
          <a href="/Event_M/logout.php">Logout</a>
        <?php else: ?>
          <a href="/Event_M/auth.php">Admin / User SignUp</a>
        <?php endif; ?>
      </nav>
    </div>
  </header>
  <main class="container">
  <?php if(!empty($_SESSION['flash'])): ?>
    <div class="flash"><?php echo esc($_SESSION['flash']); unset($_SESSION['flash']); ?></div>
  <?php endif; ?>
