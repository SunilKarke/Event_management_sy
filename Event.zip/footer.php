  </main>
  <footer>
    <div class="container">&copy; Event Management </div>
  </footer>
</body>
</html>
