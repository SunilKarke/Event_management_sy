<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/header.php';

// Fetch events ordered by datetime
$stmt = $mysqli->prepare("SELECT e.id, e.title, e.description, e.event_datetime, e.location, u.username, e.created_at FROM events e LEFT JOIN users u ON e.created_by = u.id ORDER BY e.event_datetime ASC");
$stmt->execute();
$res = $stmt->get_result();
$events = $res->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>

<div class="row">
  <div class="col">
    <h2>Upcoming events</h2>
    <p>Date: <strong><?php echo esc(date('d/m/20y ')); ?></strong></p>

    <?php if(empty($events)): ?>
      <p>No events yet.</p>
    <?php else: ?>
      <ul class="events">
      <?php foreach($events as $ev): ?>
        <li>
          <h3><?php echo esc($ev['title']); ?></h3>
          <div class="meta">
            Date: <?php echo date('F j, Y', strtotime($ev['event_datetime'])); ?><br>
            Time: <?php echo date('g:i A', strtotime($ev['event_datetime'])); ?><br>
            Location: <?php echo esc($ev['location']); ?><br>
            Created by: <?php echo esc($ev['username'] ?? '—'); ?>
          </div>
          <p><?php echo nl2br(esc($ev['description'])); ?></p> 
          <hr>
          <?php if(!empty($_SESSION['user_id']) && function_exists('is_admin') && !is_admin()): ?>
            <form method="post" action="/Event_M/apply_event.php" style="margin-top:8px;">
              <input type="hidden" name="event_id" value="<?php echo esc($ev['id']); ?>">
              <button type="submit">Apply for this event</button>
            </form>
          <?php endif; ?>
        </li>
      <?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
